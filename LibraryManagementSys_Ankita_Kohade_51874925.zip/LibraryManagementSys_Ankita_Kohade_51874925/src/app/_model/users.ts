export class Users {
    id: string;
    Title: string;
    Author: string;
    Subject: string;
    Rack_No: string;
  
    // constructor (id,Title,Author,Subject,Rack_No){
    //     this.id=id;
    //     this.Title=Title;
    //     this.Author=Author;
    //     this.Subject=Subject;
    //     this.Rack_No=Rack_No;
    // }


}